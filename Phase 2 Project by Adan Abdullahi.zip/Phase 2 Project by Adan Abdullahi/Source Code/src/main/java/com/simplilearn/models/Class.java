package com.simplilearn.models;
// main class
public class Class {

	//some useful global vairables
	private int id;
	private int section;
	private String teacher;
	private String subject;
	private String time;
	
	
	// inner class
	public Class(int id, int section, String teacher, String subject, String time) {
		super();
		this.id = id;
		this.section = section;
		this.teacher = teacher;
		this.subject = subject;
		this.time = time;
	}
	
 //this method gets Id of the student
	public int getId() {
		return id;
	}
	//this method sets Id of the student
	public void setId(int id) {
		this.id = id;
	}
	//this method gets the section of the student
	public int getSection() {
		return section;
	}
	//this method gets sets section of the student
	public void setSection(int section) {
		this.section = section;
	}
	//this method gets teacher
	public String getTeacher() {
		return teacher;
	}
	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}
	//this method gets the subject
	public String getSubject() {
		return subject;
	}
	//this method sets subject
	public void setSubject(String subject) {
		this.subject = subject;
	}
	//this method gets times
	public String getTime() {
		return time;
	}
	//this method sets time
	public void setTime(String time) {
		this.time = time;
	}
	
	

}
