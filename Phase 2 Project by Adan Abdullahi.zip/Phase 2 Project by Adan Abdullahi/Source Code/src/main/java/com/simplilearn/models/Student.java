package com.simplilearn.models;
// main class
public class Student {
	// some global vairables
	private int id;
	private String fname;
	private String lname;
	private int age;
	private int aclass;

	// method takes 5 argument as parametor	
	public Student(int id, String fname, String lname, int age, int aclass) {
		super();
		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.age = age;
		this.aclass = aclass;
	}
	
	//gets id of the student
	public int getId() {
		return id;
	}
	// sets id of the student
	public void setId(int id) {
		this.id = id;
	}
	// gets name of the student
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	// sets last name of the student
	public void setLname(String lname) {
		this.lname = lname;
	}
	// gets age of the stduent
	public int getAge() {
		return age;
	}
	// sets age of the student
	public void setAge(int age) {
		this.age = age;
	}
	// gets class of the studentt
	public int getAclass() {
		return aclass;
	}
	// sets class of the students
	public void setAclass(int aclass) {
		this.aclass = aclass;
	}


	@Override
	public String toString() {
		return "Student [id=" + id + ", fname=" + fname + ", lname=" + lname + ", age=" + age + ", aclass=" + aclass
				+ "]";
	}
 
	

}
