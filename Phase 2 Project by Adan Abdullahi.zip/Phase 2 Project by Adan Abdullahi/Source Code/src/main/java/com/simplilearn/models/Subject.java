package com.simplilearn.models;
// main calss
public class Subject {
	// some global variables 
	private int id;
	private String name;
	private String shortcut;
		// method takes 3 argument as parametor
	public Subject(int id, String name, String shortcut ) {
		super();
		this.id = id;
		this.name = name;
		this.shortcut = shortcut;
	}
// gets id of the student
	public int getId() {
		return id;
	}
	/// sets id of the student

	public void setId(int id) {
		this.id = id;
	}
	// gets shortcu
	
	public String getShortcut() {
		return shortcut;
	}

	public void setShortcut(String shortcut) {
		this.shortcut = shortcut;
	}
	// gets name

	public String getName() {
		return name;
	}
// sets name of the student
	public void setName(String name) {
		this.name = name;
	}
	
	
	

}
