package com.simplilearn.models;
// main class
public class Teacher {
	// global vairable 
	private int id;
	private String fname;
	private String lname;
	private int age;
		// method takes 4 argument as parametor
	public Teacher(int id, String fname, String lname, int age) {
		super();
		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.age = age;
	}
// gets id of the student
	public int getId() {
		return id;
	}
// sets id of the student
	public void setId(int id) {
		this.id = id;
	}
// gets name of the student
	public String getFname() {
		return fname;
	}
// sets name of the student
	public void setFname(String fname) {
		this.fname = fname;
	}
	// gets last name of the student

	public String getLname() {
		return lname;
	}
	//sets last name of the studnet

	public void setLname(String lname) {
		this.lname = lname;
	}
// gets age of the studnet
	public int getAge() {
		return age;
	}
	// sets age of the student

	public void setAge(int age) {
		this.age = age;
	}
	
	

}
